using UserCatalogService as service from '../../srv/user-service';
annotate service.AnimalsSrv with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>name}',
                Value : name,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>species}',
                Value : species,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>breed}',
                Value : breed,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>gender}',
                Value : gender,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>ageYears}',
                Value : age,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>arrivalDate}',
                Value : arrivalDate,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>adoptionStatus}',
                Value : animalStatus,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>vaccinationStatus}',
                Value : vaccinationStatus,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>spayedNeutered}',
                Value : spayedOrNeutered,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>photo}',
                Value : photo,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>description}',
                Value : description,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'HealthSummaryFacet',
            Label : '{i18n>healthEligibility}',
            Target : '@UI.FieldGroup#HealthSummary',
        },
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'HealthRecordsFacet',
            Label : '{i18n>healthRecordsUpcomingCheckups}',
            Target : 'healthRecords/@UI.LineItem',
        }
    ],
    UI.LineItem : [
        {
            $Type : 'UI.DataField',
            Label : '{i18n>name}',
            Value : name,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>species}',
            Value : species,
            ![@HTML5.CssDefaults] : { width : '7rem' }
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>breed}',
            Value : breed,
            ![@HTML5.CssDefaults] : { width : '10rem' }
        },
        {
            $Type : 'UI.DataFieldForAction',
            Action : 'UserCatalogService.applyForAdoption',
            Label : '{i18n>applyForAdoption}'
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>adoptionEligibility}',
            Value : adoptionEligibility,
            Criticality : eligibilityCriticality,
            ![@HTML5.CssDefaults] : { width : '15rem' }
        }
    ],
);

annotate service.AnimalsSrv with {
    shelter @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'SheltersSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : shelter_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'shelterName',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'shelterCode',
            },
            
        ],
    }
};



// FR-USR-004 / 016 / 017: read-only health information for adopters
annotate service.AnimalsSrv with @(
    UI.FieldGroup #HealthSummary : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : adoptionEligibility, Label : '{i18n>adoptionEligibility}', Criticality : eligibilityCriticality },
            { $Type : 'UI.DataField', Value : animalStatus,        Label : '{i18n>adoptionStatus}' },
            { $Type : 'UI.DataField', Value : vaccinationStatus,   Label : '{i18n>vaccinationStatus}' },
            { $Type : 'UI.DataField', Value : spayedOrNeutered,    Label : '{i18n>spayedNeutered}' },
            { $Type : 'UI.DataField', Value : shelter.shelterName, Label : '{i18n>shelter}' },
            { $Type : 'UI.DataField', Value : shelter.city,        Label : '{i18n>shelterCity}' }
        ]
    }
);

annotate service.HealthRecordsSrv with @(
    UI.LineItem : [
        { $Type : 'UI.DataField', Value : checkupDate,     Label : '{i18n>checkupDate}' },
        { $Type : 'UI.DataField', Value : healthStatus,    Label : '{i18n>healthStatus}' },
        { $Type : 'UI.DataField', Value : diagnosis,       Label : '{i18n>diagnosis}' },
        { $Type : 'UI.DataField', Value : treatment,       Label : '{i18n>treatment}' },
        { $Type : 'UI.DataField', Value : nextCheckupDate, Label : '{i18n>nextCheckup}' },
        { $Type : 'UI.DataField', Value : checkupStatus,   Label : '{i18n>checkupStatus}', Criticality : checkupCriticality },
        { $Type : 'UI.DataField', Value : medicalDocument, Label : '{i18n>healthCertificate}' }
    ],
    UI.PresentationVariant : {
        SortOrder : [ { Property : checkupDate, Descending : true } ],
        Visualizations : [ '@UI.LineItem' ]
    }
);
