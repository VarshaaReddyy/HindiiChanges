using { db } from './schema';

// ==========================================================
// FIELD LABELS
// Readable names used by every Fiori page (columns, filters,
// forms, value helps) when no explicit label is given.
// UI text only: nothing in the database changes.
// ==========================================================

annotate db.Users with {
    ID          @title : '{i18n>userID}';
    firstName   @title : '{i18n>firstName}';
    lastName    @title : '{i18n>lastName}';
    email       @title : '{i18n>email}';
    phoneNumber @title : '{i18n>phone}';
    address     @title : '{i18n>address}';
    city        @title : '{i18n>city}';
    state       @title : '{i18n>state}';
    postalCode  @title : '{i18n>postalCode}';
    role        @title : '{i18n>role}';
    status      @title : '{i18n>accountStatus}';
};

annotate db.Shelters with {
    ID               @title : '{i18n>shelterID}';
    shelterName      @title : '{i18n>shelterName}';
    shelterCode      @title : '{i18n>shelterCode}';
    addressLine1     @title : '{i18n>addressLine1}';
    addressLine2     @title : '{i18n>addressLine2}';
    city             @title : '{i18n>city}';
    state            @title : '{i18n>state}';
    postalCode       @title : '{i18n>postalCode}';
    country          @title : '{i18n>country}';
    contactNumber    @title : '{i18n>contactNumber}';
    email            @title : '{i18n>email}';
    website          @title : '{i18n>website}';
    capacity         @title : '{i18n>capacity}';
    currentOccupancy @title : '{i18n>currentOccupancy}';
    operatingTime    @title : '{i18n>openingTime}';
    closingTime      @title : '{i18n>closingTime}';
    shelterType      @title : '{i18n>shelterType}';
    licenseNumber    @title : '{i18n>licenseNumber}';
};

annotate db.Animals with {
    ID                @title : '{i18n>animalID}';
    shelter           @title : '{i18n>shelter}';
    name              @title : '{i18n>name}';
    species           @title : '{i18n>species}';
    breed             @title : '{i18n>breed}';
    gender            @title : '{i18n>gender}';
    age               @title : '{i18n>ageYears}';
    arrivalDate       @title : '{i18n>arrivalDate}';
    animalStatus      @title : '{i18n>adoptionStatus}';
    vaccinationStatus @title : '{i18n>vaccinationStatus}';
    spayedOrNeutered  @title : '{i18n>spayedNeutered}';
    photo             @title : '{i18n>photo}';
    description       @title : '{i18n>description}';
};

annotate db.AdoptionApplications with {
    ID                @title : '{i18n>applicationID}';
    animal            @title : '{i18n>animal}';
    applicant         @title : '{i18n>applicant}';
    applicationDate   @title : '{i18n>applicationDate}';
    reasonForAdoption @title : '{i18n>reasonForAdoption}';
    housingDetails    @title : '{i18n>housingDetails}';
    petExperience     @title : '{i18n>petExperience}';
    status            @title : '{i18n>status}';
    reviewedBy        @title : '{i18n>reviewedBy}';
    staffRemarks      @title : '{i18n>reviewerComments}';
};

annotate db.Adoptions with {
    ID           @title : '{i18n>adoptionID}';
    application  @title : '{i18n>application}';
    animal       @title : '{i18n>animal}';
    adoptionDate @title : '{i18n>adoptionDate}';
    status       @title : '{i18n>status}';
    completedBy  @title : '{i18n>completedBy}';
    remarks      @title : '{i18n>remarks}';
};

annotate db.HealthRecords with {
    ID               @title : '{i18n>healthRecordID}';
    animal           @title : '{i18n>animal}';
    checkupDate      @title : '{i18n>checkupDate}';
    healthStatus     @title : '{i18n>healthStatus}';
    diagnosis        @title : '{i18n>diagnosis}';
    treatment        @title : '{i18n>treatment}';
    medication       @title : '{i18n>medication}';
    veterinarianName @title : '{i18n>veterinarian}';
    weight           @title : '{i18n>weightKg}';
    nextCheckupDate  @title : '{i18n>nextCheckup}';
    remarks          @title : '{i18n>remarks}';
    medicalDocument  @title : '{i18n>medicalDocument}';
};

annotate db.Inspections with {
    ID                 @title : '{i18n>inspectionID}';
    adoption           @title : '{i18n>adoption}';
    inspector          @title : '{i18n>inspector}';
    inspectionDate     @title : '{i18n>inspectionDate}';
    inspectionType     @title : '{i18n>inspectionType}';
    existingPetDetails @title : '{i18n>existingPetDetails}';
    result             @title : '{i18n>result}';
    remarks            @title : '{i18n>remarks}';
    inspectionDocument @title : '{i18n>inspectionDocument}';
};

annotate db.ApplicationStatusHistory with {
    oldStatus @title : '{i18n>fromStatus}';
    newStatus @title : '{i18n>toStatus}';
    changedBy @title : '{i18n>changedBy}';
    changedAt @title : '{i18n>changedAt}';
    remarks   @title : '{i18n>remarks}';
};


// ==========================================================
// RELATED RECORDS SHOWN BY NAME (not by ID) in tables, forms
// and value helps; technical IDs hidden in the UI
// ==========================================================

annotate db.Animals with {
    ID      @UI.Hidden;
    shelter @Common.Text : shelter.shelterName  @Common.TextArrangement : #TextOnly;
};

annotate db.Shelters with {
    ID @UI.Hidden;
};

annotate db.Users with {
    ID @UI.Hidden;
};

annotate db.HealthRecords with {
    ID     @UI.Hidden;
    animal @Common.Text : animal.name  @Common.TextArrangement : #TextOnly;
};

annotate db.Inspections with {
    ID        @UI.Hidden;
    adoption  @Common.Text : adoption.animal.name  @Common.TextArrangement : #TextOnly;
    inspector @Common.Text : inspector.firstName   @Common.TextArrangement : #TextOnly;
};

annotate db.AdoptionApplications with {
    animal     @Common.Text : animal.name           @Common.TextArrangement : #TextOnly;
    applicant  @Common.Text : applicant.firstName   @Common.TextArrangement : #TextOnly;
    reviewedBy @Common.Text : reviewedBy.firstName  @Common.TextArrangement : #TextOnly;
};

annotate db.Adoptions with {
    ID          @UI.Hidden;
    application @UI.Hidden;
    animal      @Common.Text : animal.name           @Common.TextArrangement : #TextOnly;
    completedBy @Common.Text : completedBy.firstName @Common.TextArrangement : #TextOnly;
};
