using CatalogService as service from '../../srv/cat-service';


annotate service.AdoptionApplicationsSrv with @(

    UI.HeaderInfo : {
        TypeName : '{i18n>application}',
        TypeNamePlural : '{i18n>applications}',
        Title : { Value : animal.name },
        Description : { Value : applicant.email }
    },
    UI.LineItem : [
    // FRD Fiori UI #4: applicant, animal, status, date
    {
        $Type : 'UI.DataField',
        Value : applicationDate,
        Label : '{i18n>applicationDate}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : applicant.firstName,
        Label : '{i18n>applicant}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : animal.name,
        Label : '{i18n>animal}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : status,
        Label : '{i18n>status}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : reasonForAdoption,
        Label : '{i18n>reasonForAdoption}',
            ![@HTML5.CssDefaults] : { width : '14rem' }
        },
    {
        $Type : 'UI.DataFieldForAction',
        Action : 'CatalogService.markUnderReview',
        Label : '{i18n>startReview}'
    },
    {
        $Type : 'UI.DataFieldForAction',
        Action : 'CatalogService.approveApplication',
        Label : '{i18n>approve}',
        Inline :true

    },
    {
        $Type : 'UI.DataFieldForAction',
        Action : 'CatalogService.rejectApplication',
        Label : '{i18n>reject}',
        Inline : true
    },
    
],
    UI.SelectionFields : [
        status,
        applicationDate
    ],
    // Approve / Reject / Start Review also on the object page header
    UI.Identification : [
        {
            $Type : 'UI.DataFieldForAction',
            Action : 'CatalogService.markUnderReview',
            Label : '{i18n>startReview}'
        },
        {
            $Type : 'UI.DataFieldForAction',
            Action : 'CatalogService.approveApplication',
            Label : '{i18n>approve}'
        },
        {
            $Type : 'UI.DataFieldForAction',
            Action : 'CatalogService.rejectApplication',
            Label : '{i18n>reject}'
        }
    ],
    // FRD Fiori UI #5: applicant and animal information
    UI.FieldGroup #Applicant : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : applicant.firstName,   Label : '{i18n>firstName}' },
            { $Type : 'UI.DataField', Value : applicant.lastName,    Label : '{i18n>lastName}' },
            { $Type : 'UI.DataField', Value : applicant.email,       Label : '{i18n>email}' },
            { $Type : 'UI.DataField', Value : applicant.phoneNumber, Label : '{i18n>phone}' },
            { $Type : 'UI.DataField', Value : applicant.city,        Label : '{i18n>city}' }
        ]
    },
    UI.FieldGroup #Animal : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : animal.name,         Label : '{i18n>name}' },
            { $Type : 'UI.DataField', Value : animal.species,      Label : '{i18n>species}' },
            { $Type : 'UI.DataField', Value : animal.breed,        Label : '{i18n>breed}' },
            { $Type : 'UI.DataField', Value : animal.age,          Label : '{i18n>ageYears}' },
            { $Type : 'UI.DataField', Value : animal.animalStatus, Label : '{i18n>adoptionStatus}' }
        ]
    },
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>applicationDate}',
                Value : applicationDate,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>reasonForAdoption}',
                Value : reasonForAdoption,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>housingDetails}',
                Value : housingDetails,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>petExperience}',
                Value : petExperience,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>status}',
                Value : status,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>reviewerComments}',
                Value : staffRemarks,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>applicationDetails}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'ApplicantFacet',
            Label : '{i18n>applicantInformation}',
            Target : '@UI.FieldGroup#Applicant',
        },
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'AnimalFacet',
            Label : '{i18n>animalInformation}',
            Target : '@UI.FieldGroup#Animal',
        },
        // FRD Fiori UI #6: application audit history
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'HistoryFacet',
            Label : '{i18n>statusHistory}',
            Target : 'history/@UI.LineItem',
        },
    ],
  

    Capabilities.InsertRestrictions : {
        Insertable : false
    },


    Capabilities.DeleteRestrictions : {
        Deletable : false
    }


);

annotate service.AdoptionApplicationsSrv with {
    animal @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'AnimalsSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : animal_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'name',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'species',
            },
        ],
    }
};

annotate service.AdoptionApplicationsSrv with {
    applicant @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'UsersSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : applicant_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'firstName',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'lastName',
            },
        ],
    }
};

annotate service.AdoptionApplicationsSrv with {
    reviewedBy @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'UsersSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : reviewedBy_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'firstName',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'lastName',
            },
        ],
    }
};


// ==========================================================
// STATUS HISTORY TABLE (shown on the application object page)
// ==========================================================

annotate service.ApplicationStatusHistorySrv with @(
    UI.LineItem : [
        { $Type : 'UI.DataField', Value : changedAt, Label : '{i18n>changedAt}' },
        { $Type : 'UI.DataField', Value : oldStatus, Label : '{i18n>from}' },
        { $Type : 'UI.DataField', Value : newStatus, Label : '{i18n>to}' },
        { $Type : 'UI.DataField', Value : changedBy, Label : '{i18n>changedBy}' },
        { $Type : 'UI.DataField', Value : remarks,   Label : '{i18n>remarks}',
            ![@HTML5.CssDefaults] : { width : '14rem' }
        }
    ],
    UI.PresentationVariant : {
        SortOrder : [ { Property : changedAt, Descending : true } ],
        Visualizations : [ '@UI.LineItem' ]
    }
);

// Label of the parameter in the Reject dialog
annotate service.AdoptionApplicationsSrv actions {
    rejectApplication(reason @title : '{i18n>rejectionReason}' @UI.MultiLineText);
};


// Actions enabled only for the right statuses
annotate service.AdoptionApplicationsSrv actions {
    markUnderReview    @Core.OperationAvailable : { $edmJson : { $Eq : [ { $Path : 'in/status' }, 'SUBMITTED' ] } };
    approveApplication @Core.OperationAvailable : { $edmJson : { $Or : [
                            { $Eq : [ { $Path : 'in/status' }, 'SUBMITTED' ] },
                            { $Eq : [ { $Path : 'in/status' }, 'UNDER_REVIEW' ] } ] } };
    rejectApplication  @Core.OperationAvailable : { $edmJson : { $Or : [
                            { $Eq : [ { $Path : 'in/status' }, 'SUBMITTED' ] },
                            { $Eq : [ { $Path : 'in/status' }, 'UNDER_REVIEW' ] } ] } };
};
