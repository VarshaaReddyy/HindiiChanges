using UserCatalogService as service from '../../srv/user-service';

// ==========================================================
// MY ADOPTIONS (FR-USR-012 .. 015, FR-USR-019)
// ==========================================================

annotate service.AdoptionsSrv with @(

    UI.HeaderInfo : {
        TypeName       : '{i18n>adoption}',
        TypeNamePlural : '{i18n>myAdoptions}',
        Title          : { Value : animal.name },
        Description    : { Value : animal.breed }
    },

    UI.LineItem : [
        { $Type : 'UI.DataField', Value : animal.name,         Label : '{i18n>animal}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { $Type : 'UI.DataField', Value : animal.species,      Label : '{i18n>species}',
            ![@HTML5.CssDefaults] : { width : '7rem' }
        },
        { $Type : 'UI.DataField', Value : adoptionDate,        Label : '{i18n>adoptionDate}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { $Type : 'UI.DataField', Value : animal.shelter.shelterName, Label : '{i18n>adoptedFrom}',
            ![@HTML5.CssDefaults] : { width : '11rem' }
        },
        { $Type : 'UI.DataField', Value : status,              Label : '{i18n>status}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        }
    ],

    UI.FieldGroup #Adoption : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : adoptionDate, Label : '{i18n>adoptionDate}' },
            { $Type : 'UI.DataField', Value : status,       Label : '{i18n>status}' },
            { $Type : 'UI.DataField', Value : remarks,      Label : '{i18n>remarks}' }
        ]
    },

    UI.FieldGroup #Animal : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : animal.name,              Label : '{i18n>name}' },
            { $Type : 'UI.DataField', Value : animal.species,           Label : '{i18n>species}' },
            { $Type : 'UI.DataField', Value : animal.breed,             Label : '{i18n>breed}' },
            { $Type : 'UI.DataField', Value : animal.gender,            Label : '{i18n>gender}' },
            { $Type : 'UI.DataField', Value : animal.age,               Label : '{i18n>ageYears}' },
            { $Type : 'UI.DataField', Value : animal.vaccinationStatus, Label : '{i18n>vaccinationStatus}' }
        ]
    },

    UI.FieldGroup #Shelter : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : animal.shelter.shelterName,   Label : '{i18n>shelter}' },
            { $Type : 'UI.DataField', Value : animal.shelter.city,          Label : '{i18n>city}' },
            { $Type : 'UI.DataField', Value : animal.shelter.contactNumber, Label : '{i18n>contactNumber}' },
            { $Type : 'UI.DataField', Value : animal.shelter.email,         Label : '{i18n>email}' }
        ]
    },

    UI.Facets : [
        { $Type : 'UI.ReferenceFacet', ID : 'AdoptionFacet',    Label : '{i18n>adoption}',    Target : '@UI.FieldGroup#Adoption' },
        { $Type : 'UI.ReferenceFacet', ID : 'AnimalFacet',      Label : '{i18n>animal}',      Target : '@UI.FieldGroup#Animal' },
        { $Type : 'UI.ReferenceFacet', ID : 'ShelterFacet',     Label : '{i18n>shelter}',     Target : '@UI.FieldGroup#Shelter' },
        // FR-USR-019: post-adoption inspection status and result
        { $Type : 'UI.ReferenceFacet', ID : 'InspectionsFacet', Label : '{i18n>postAdoptionInspections}', Target : 'inspections/@UI.LineItem' }
    ]
);

annotate service.InspectionsSrv with @(
    UI.LineItem : [
        { $Type : 'UI.DataField', Value : inspectionDate,     Label : '{i18n>inspectionDate}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { $Type : 'UI.DataField', Value : inspectionType,     Label : '{i18n>type}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { $Type : 'UI.DataField', Value : result,             Label : '{i18n>result}',
            ![@HTML5.CssDefaults] : { width : '6rem' }
        },
        { $Type : 'UI.DataField', Value : remarks,            Label : '{i18n>remarks}',
            ![@HTML5.CssDefaults] : { width : '14rem' }
        },
        { $Type : 'UI.DataField', Value : inspectionDocument, Label : '{i18n>inspectionDocument}' }
    ]
);
