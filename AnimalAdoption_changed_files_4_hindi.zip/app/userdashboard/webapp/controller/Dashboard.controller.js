sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/base/i18n/Localization"
], function (
    Controller,
    JSONModel,
    MessageToast,
    Localization
) {
    "use strict";

    var SERVICE = "/odata/v4/user-catalog/";


    var STATUS_STATE = {
        SUBMITTED: "Information",
        UNDER_REVIEW: "Warning",
        APPROVED: "Success",
        REJECTED: "Error",
        WITHDRAWN: "None",
        AVAILABLE: "Success",
        RESERVED: "Warning",
        ADOPTED: "Information"
    };

    var STATUS_ICON = {
        SUBMITTED: "sap-icon://paper-plane",
        UNDER_REVIEW: "sap-icon://search",
        APPROVED: "sap-icon://accept",
        REJECTED: "sap-icon://decline",
        WITHDRAWN: "sap-icon://undo"
    };

    return Controller.extend(
        "animal.adoption.userdashboard.controller.Dashboard",
        {

            // =====================================================
            // FORMATTERS
            // =====================================================

            formatStatusText: function (sStatus) {
                if (!sStatus) { return ""; }
                var sText = this._t("status_" + sStatus);
                return sText === "status_" + sStatus ? sStatus : sText;
            },

            // "Labrador · 3 yrs · Happy Tails" in the current language
            formatAnimalMeta: function (sBreed, iAge, sShelter) {
                return [sBreed, iAge != null ? this._t("yearsShort", [iAge]) : "", sShelter]
                    .filter(Boolean).join(" · ");
            },

            // History remark (standard remarks translated) + date
            formatUpdateMeta: function (sRemarks, sDate) {
                var mKnown = {
                    "Application submitted": "remarkSubmitted",
                    "Review started": "remarkReviewStarted",
                    "Application approved": "remarkApproved",
                    "Withdrawn by applicant": "remarkWithdrawn",
                    "Withdrawn by applicant.": "remarkWithdrawn",
                    "Animal has been adopted by another applicant.": "remarkAdoptedByOther"
                };
                var sText = mKnown[sRemarks] ? this._t(mKnown[sRemarks]) : (sRemarks || "");
                return [sText, this.formatDateTime(sDate)].filter(Boolean).join(" · ");
            },

            formatStatusState: function (sStatus) {
                return STATUS_STATE[sStatus] || "None";
            },

            formatStatusIcon: function (sStatus) {
                return STATUS_ICON[sStatus] || "sap-icon://history";
            },

            formatDate: function (sDate) {
                if (!sDate) { return ""; }
                return new Date(sDate).toLocaleDateString(this._locale(), {
                    month: "short", day: "numeric", year: "numeric"
                });
            },

            formatDateTime: function (sDate) {
                if (!sDate) { return ""; }
                return new Date(sDate).toLocaleString(this._locale(), {
                    month: "short", day: "numeric", hour: "numeric", minute: "2-digit"
                });
            },

            formatAnimalImage: function (sSpecies) {
                return (sSpecies === "Cat") ? "images/cat.jpg"
                    : (sSpecies === "Dog") ? "images/dog.jpg"
                    : "images/pets.jpg";
            },



            // =====================================================
            // LANGUAGE (English / Hindi)
            // The choice is kept in the browser (localStorage) so every
            // app opened afterwards uses it (see index.html).
            // =====================================================

            _lang: function () {
                return String(Localization.getLanguage() || "en").toLowerCase().indexOf("hi") === 0 ? "hi" : "en";
            },

            _locale: function () {
                return this._lang() === "hi" ? "hi-IN" : "en-US";
            },

            _t: function (sKey, aArgs) {
                return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sKey, aArgs);
            },

            onLanguageToggle: function () {
                var sNew = this._lang() === "hi" ? "en" : "hi";
                try { window.localStorage.setItem("af-lang", sNew); } catch (e) { /* storage blocked: URL parameter still works */ }
                window.location.replace(window.location.pathname + "?sap-language=" + sNew + window.location.hash);
            },


            // =====================================================
            // INIT
            // =====================================================

            onInit: function () {

                var oView = this.getView();

                oView.setModel(new JSONModel({
                    name: "",
                    welcome: this._t("welcomeBack"),
                    availableCount: 0,
                    errorText: ""
                }), "view");

                oView.setModel(new JSONModel({
                    myApplications: 0,
                    pendingApplications: 0,
                    approvedApplications: 0,
                    myAdoptions: 0
                }), "dashboard");

                oView.setModel(new JSONModel([]), "applications");
                oView.setModel(new JSONModel([]), "animals");
                oView.setModel(new JSONModel([]), "updates");

                this._loadAll();
            },


            // =====================================================
            // DATA LOADING (backend filters everything by the
            // logged-in user)
            // =====================================================

            _get: function (sUrl) {
                // Accept-Language: the backend answers in the same language
                return fetch(sUrl, { headers: { "Accept-Language": this._lang() } }).then(function (oResponse) {
                    if (!oResponse.ok) {
                        throw new Error("HTTP " + oResponse.status);
                    }
                    return oResponse.json();
                });
            },

            _loadAll: function () {

                var that = this;
                var oView = this.getView();

                // Display name for the welcome banner
                this._get("/odata/v4/app/whoAmI()").then(function (oMe) {
                    oView.getModel("view").setProperty("/name", oMe.name || "");
                    oView.getModel("view").setProperty("/welcome",
                        that._t("welcomeBack") + (oMe.name ? ", " + oMe.name : ""));
                }).catch(function () { /* optional */ });

                Promise.allSettled([

                    this._get(SERVICE + "UserDashboardStats").then(function (oResult) {
                        oView.getModel("dashboard").setData((oResult.value || [])[0] || {});
                    }),

                    this._get(SERVICE + "AdoptionApplicationsSrv" +
                        "?$expand=animal($select=name,breed,species)" +
                        "&$orderby=applicationDate desc").then(function (oResult) {
                        oView.getModel("applications").setData(oResult.value || []);
                    }),

                    this._get(SERVICE + "AnimalsSrv" +
                        "?$filter=animalStatus eq 'AVAILABLE'" +
                        "&$orderby=arrivalDate desc&$top=3&$count=true" +
                        "&$expand=shelter($select=shelterName)").then(function (oResult) {
                        oView.getModel("animals").setData(oResult.value || []);
                        oView.getModel("view").setProperty("/availableCount", oResult["@odata.count"] || 0);
                    }),

                    this._get(SERVICE + "ApplicationStatusHistorySrv" +
                        "?$orderby=changedAt desc&$top=4" +
                        "&$expand=application($select=ID;$expand=animal($select=name))").then(function (oResult) {
                        oView.getModel("updates").setData(oResult.value || []);
                    })

                ]).then(function (aResults) {

                    var oFailed = aResults.find(function (oResult) {
                        return oResult.status === "rejected";
                    });

                    if (oFailed) {
                        var sReason = String(oFailed.reason && oFailed.reason.message || "");
                        oView.getModel("view").setProperty("/errorText",
                            /403/.test(sReason)
                                ? that._t("errUserRole")
                                : that._t("errLoad", [sReason])
                        );
                    }

                    that._loaded = true;
                });
            },


            // =====================================================
            // REFRESH
            // =====================================================

            onRefresh: function () {

                this.getView().getModel("view").setProperty("/errorText", "");
                this._loadAll();

                MessageToast.show(this._t("refreshed"));
            },


            // =====================================================
            // BACK
            // =====================================================

            onNavBack: function () {

                window.history.back();
            },


            // =====================================================
            // NAVIGATION
            // =====================================================

            onBrowseAnimalsPress: function () {

                window.location.href =
                    "/useranimals/index.html";
            },

            onMyApplicationsPress: function () {

                window.location.href =
                    "/userapplications/index.html";
            },

            onMyAdoptionsPress: function () {

                window.location.href =
                    "/useradoptions/index.html";
            },

            // Opens the user's own profile record directly (object page)
            onProfilePress: function () {

                this._get(SERVICE + "UsersSrv?$select=ID&$top=1")
                    .then(function (oResult) {
                        var oMe = (oResult.value || [])[0];
                        window.location.href = oMe
                            ? "/userprofile/index.html#/UsersSrv(ID=" + oMe.ID + ",IsActiveEntity=true)"
                            : "/userprofile/index.html";
                    })
                    .catch(function () {
                        window.location.href = "/userprofile/index.html";
                    });
            }

        }
    );
});
