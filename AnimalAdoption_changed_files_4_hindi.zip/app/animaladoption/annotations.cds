using CatalogService as service from '../../srv/cat-service';

using UI from '@sap/cds/common';


annotate CatalogService.UsersSrv with @(
    UI.HeaderInfo : {
        TypeName : '{i18n>user}',
        TypeNamePlural : '{i18n>users}'
    },

    UI.SelectionFields : [
        firstName,
        lastName,
        role,
        status
    ],

    UI.LineItem : [
        { Value : firstName,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : lastName,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : email,
            ![@HTML5.CssDefaults] : { width : '14rem' }
        },
        { Value : role,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : status,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        }
    ]
);

annotate CatalogService.SheltersSrv with @(
    UI.HeaderInfo : {
        TypeName : '{i18n>shelter}',
        TypeNamePlural : '{i18n>shelters}'
    },

    UI.SelectionFields : [
        shelterName,
        city,
        shelterType
    ],

    UI.LineItem : [
        { Value : shelterName,
            ![@HTML5.CssDefaults] : { width : '11rem' }
        },
        { Value : city,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : state,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : capacity,
            ![@HTML5.CssDefaults] : { width : '6rem' }
        },
        { Value : shelterType,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        }
    ]
);




annotate CatalogService.AdoptionsSrv with @(
    UI.HeaderInfo : {
        TypeName : '{i18n>adoption}',
        TypeNamePlural : '{i18n>adoptions}'
    },

    UI.LineItem : [
        { Value : animal_ID, Label : '{i18n>animal}', ![@HTML5.CssDefaults] : { width : '8rem' } },
        { Value : application.applicant.firstName, Label : '{i18n>adopter}', ![@HTML5.CssDefaults] : { width : '8rem' } },
        { Value : adoptionDate,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : status,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : remarks,
            ![@HTML5.CssDefaults] : { width : '14rem' }
        }
    ]
);



annotate CatalogService.InspectionsSrv with @(
    UI.HeaderInfo : {
        TypeName : '{i18n>inspection}',
        TypeNamePlural : '{i18n>inspections}'
    },

    UI.LineItem : [
        { Value : adoption_ID, Label : '{i18n>animal}', ![@HTML5.CssDefaults] : { width : '8rem' } },
        { Value : inspector_ID, Label : '{i18n>inspector}', ![@HTML5.CssDefaults] : { width : '8rem' } },
        { Value : inspectionDate,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : inspectionType,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : result,
            ![@HTML5.CssDefaults] : { width : '6rem' }
        }
    ]
);