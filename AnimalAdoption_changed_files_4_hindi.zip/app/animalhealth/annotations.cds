using CatalogService as service from '../../srv/cat-service';
annotate service.HealthRecordsSrv with @(
    UI.HeaderInfo : {
        TypeName : '{i18n>healthRecord}',
        TypeNamePlural : '{i18n>healthRecords}'
    },

    UI.LineItem : [
        { Value : animal_ID,        Label : '{i18n>animal}',
            ![@HTML5.CssDefaults] : { width : '7rem' }
        },
        { Value : checkupDate,      Label : '{i18n>checkupDate}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        { Value : healthStatus,     Label : '{i18n>healthStatus}',
            ![@HTML5.CssDefaults] : { width : '9rem' }
        },
        { Value : veterinarianName, Label : '{i18n>veterinarian}',
            ![@HTML5.CssDefaults] : { width : '10rem' }
        },
        { Value : nextCheckupDate,  Label : '{i18n>nextCheckup}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        // FR-ADM-014: overdue / due soon / scheduled
        { Value : checkupStatus,    Label : '{i18n>checkupStatus}', Criticality : checkupCriticality,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        }
    ],
    UI.SelectionFields : [ animal_ID, healthStatus, nextCheckupDate ],
    UI.PresentationVariant : {
        SortOrder : [ { Property : nextCheckupDate, Descending : false } ],
        Visualizations : [ '@UI.LineItem' ]
    },
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>checkupDate}',
                Value : checkupDate,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>healthStatus}',
                Value : healthStatus,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>diagnosis}',
                Value : diagnosis,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>treatment}',
                Value : treatment,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>medication}',
                Value : medication,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>veterinarianName}',
                Value : veterinarianName,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>weightKg}',
                Value : weight,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>nextCheckup}',
                Value : nextCheckupDate,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>remarks}',
                Value : remarks,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>medicalDocument}',
                Value : medicalDocument,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
        // FR-ADM-015: change history of this health record
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'ChangesFacet',
            Label : '{i18n>changeHistory}',
            Target : 'changes/@UI.LineItem',
        }
    ],
);

annotate service.HealthRecordsSrv with {
    animal @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'AnimalsSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : animal_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'name',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'species',
            },
        ],
    }
};



annotate service.HealthRecordChangesSrv with @(
    UI.LineItem : [
        { $Type : 'UI.DataField', Value : changedAt, Label : '{i18n>changedAt}' },
        { $Type : 'UI.DataField', Value : field,     Label : '{i18n>field}' },
        { $Type : 'UI.DataField', Value : oldValue,  Label : '{i18n>oldValue}' },
        { $Type : 'UI.DataField', Value : newValue,  Label : '{i18n>newValue}' },
        { $Type : 'UI.DataField', Value : changedBy, Label : '{i18n>changedBy}' }
    ],
    UI.PresentationVariant : {
        SortOrder : [ { Property : changedAt, Descending : true } ],
        Visualizations : [ '@UI.LineItem' ]
    }
);
