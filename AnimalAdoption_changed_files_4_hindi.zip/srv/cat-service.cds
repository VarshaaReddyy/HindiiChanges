using { db as my } from '../db/schema';
using from '../db/statustexts';

using {
    db.common.GUID,
    db.common.Name,
    db.common.Address,
    db.common.Email,
    db.common.PhoneNumber,
    db.common.Website,
    db.common.PostalCode,
    db.common.City,
    db.common.State,
    db.common.Description,
    db.common.Weight,

    db.common.UserRole,
    db.common.UserStatus,
    db.common.AnimalStatus,
    db.common.VaccinationStatus,
    db.common.ApplicationStatus,
    db.common.AdoptionStatus,
    db.common.HealthStatus,
    db.common.InspectionType,
    db.common.InspectionResult,
    db.common.ShelterType,
    db.common.YesNo
} from '../db/common';

// AdoptionsSrv: read-only (records created on approval)
annotate CatalogService.UsersSrv with @odata.draft.enabled ;   // standard Fiori Create / Edit / Save
annotate CatalogService.HealthRecordsSrv with @odata.draft.enabled ;   // standard Fiori Create / Edit / Save
annotate CatalogService.AnimalsSrv with @odata.draft.enabled ;   // standard Fiori Create / Edit / Save
// AdoptionApplicationsSrv: review actions instead of editing
annotate CatalogService.InspectionsSrv with @odata.draft.enabled ;   // standard Fiori Create / Edit / Save
annotate CatalogService.SheltersSrv with @odata.draft.enabled ;   // standard Fiori Create / Edit / Save

@requires: 'Admin'
service CatalogService {

    // =========================================================
    // SERVICE ENTITIES
    // =========================================================

    entity UsersSrv
        as projection on my.Users;

    entity SheltersSrv
    as projection on my.Shelters
    actions {
        action editShelter(
            shelterName      : Name,
            shelterCode      : String(20),
            addressLine1     : Address,
            addressLine2     : Address,
            city             : City,
            state            : State,
            postalCode       : String(20),
            country          : String(50),
            contactNumber    : PhoneNumber,
            email            : Email,
            website          : Website,
            capacity         : Integer,
            currentOccupancy : Integer,
            operatingTime    : Time,
            closingTime      : Time,
            shelterType      : ShelterType,
            licenseNumber    : String(50)
        ) returns SheltersSrv;
    };

    entity AnimalsSrv
    as projection on my.Animals
    actions {
        action editAnimal(
            shelterID         : GUID,
            name              : Name,
            species           : String(100),
            breed             : String(100),
            gender            : String(20),
            age               : Integer,
            arrivalDate       : Date,
            animalStatus      : AnimalStatus,
            vaccinationStatus : VaccinationStatus,
            spayedOrNeutered  : YesNo,
            photo             : String(500),
            description       : Description
        ) returns AnimalsSrv;
    };

    entity AdoptionApplicationsSrv
        as projection on my.AdoptionApplications
        actions {

            // Submitted -> Under Review
            action markUnderReview() returns String;

            // Submitted / Under Review -> Approved (creates the adoption record)
            action approveApplication() returns String;

            // Submitted / Under Review -> Rejected, reason shown to the applicant
            action rejectApplication(
                @mandatory reason : Description
            ) returns String;
        };

    // Readable texts for status codes (display + dropdowns)
    @readonly
    entity StatusTexts as projection on my.StatusTexts;

    // Health record change history (read-only, FR-ADM-015)
    @readonly
    entity HealthRecordChangesSrv
        as projection on my.HealthRecordChanges;

    // Status history of applications (read-only audit trail, FR-ADM-009)
    @readonly
    entity ApplicationStatusHistorySrv
        as projection on my.ApplicationStatusHistory;

    // Adoption records are created automatically on approval
    // and are read-only for the admin (FR-ADM-010)
    @readonly
    entity AdoptionsSrv
        as projection on my.Adoptions;

    entity HealthRecordsSrv
    as projection on my.HealthRecords
    actions {
        action editHealthRecord(
            animalID         : GUID,
            checkupDate      : Date,
            healthStatus     : HealthStatus,
            diagnosis        : Description,
            treatment        : Description,
            medication       : Description,
            veterinarianName : Name,
            weight           : Weight,
            nextCheckupDate  : Date,
            remarks          : Description,
            medicalDocument  : String(500)
        ) returns HealthRecordsSrv;
    };

    entity InspectionsSrv
    as projection on my.Inspections
    actions {
        action editInspection(
            adoptionID         : GUID,
            inspectorID        : GUID,
            inspectionDate     : Date,
            inspectionType     : InspectionType,
            existingPetDetails : Description,
            result             : InspectionResult,
            remarks            : Description,
            inspectionDocument : String(500)
        ) returns InspectionsSrv;
    };


    // =========================================================
    // DASHBOARD ENTITIES
    // =========================================================

    @readonly
    entity DashboardStats {

        key ID : String;

        totalAnimals         : Integer;
        availableAnimals     : Integer;
        totalApplications    : Integer;
        approvedApplications : Integer;
        pendingApplications  : Integer;
        totalShelters        : Integer;
    }


    @readonly
    entity UserDashboardStats {

        key ID : String;

        myApplications       : Integer;
        pendingApplications  : Integer;
        approvedApplications : Integer;
    }


    @readonly
    entity ApplicationStatusSummary {

        key status : String;
        code       : String;   // stable status code (colours), status = translated name
        count      : Integer;
    }


    @readonly
    entity AdoptionTrend {

        key month : String;
        count     : Integer;
    }


    @readonly
    entity ShelterOccupancy {

        key shelterName : String;

        city                : String;
        capacity            : Integer;
        currentOccupancy    : Integer;
        occupancyPercentage : Decimal(5,2);
    }


    @readonly
    entity AnimalCategorySummary {

        key species : String;
        count       : Integer;
    }


    // =========================================================
    // USER ACTIONS
    // =========================================================

    action createUser(
        firstName   : Name,
        lastName    : Name,
        email       : Email,
        phoneNumber : PhoneNumber,
        address     : Address,
        city        : City,
        state       : State,
        postalCode  : PostalCode,
        role        : UserRole,
        status      : UserStatus
    ) returns UsersSrv;


    action deleteUser(
        ID : GUID
    ) returns String;


    // =========================================================
    // SHELTER ACTIONS
    // =========================================================

    action createShelter(
        shelterName      : Name,
        shelterCode      : String(20),
        addressLine1     : Address,
        addressLine2     : Address,
        city              : City,
        state             : State,
        postalCode        : PostalCode,
        country           : String(50),
        contactNumber    : PhoneNumber,
        email             : Email,
        website           : Website,
        capacity          : Integer,
        currentOccupancy : Integer,
        operatingTime    : Time,
        closingTime      : Time,
        shelterType      : ShelterType,
        licenseNumber    : String(50)
    ) returns SheltersSrv;


    action deleteShelter(
        ID : GUID
    ) returns String;


    // =========================================================
    // ANIMAL ACTIONS
    // =========================================================

    action createAnimal(
        shelterID         : GUID,
        name               : Name,
        species            : String(100),
        breed              : String(100),
        gender             : String(20),
        age                : Integer,
        arrivalDate        : Date,
        animalStatus       : AnimalStatus,
        vaccinationStatus  : VaccinationStatus,
        spayedOrNeutered   : YesNo,
        photo              : String(500),
        description        : Description
    ) returns AnimalsSrv;


    action deleteAnimal(
        ID : GUID
    ) returns String;


    // =========================================================
    // APPLICATION ACTIONS
    // =========================================================

    action createApplication(
        animalID          : GUID,
        applicantID       : GUID,
        applicationDate   : Date,
        reasonForAdoption : Description,
        housingDetails    : Description,
        petExperience     : Description,
        status            : ApplicationStatus,
        reviewedByID      : GUID,
        staffRemarks      : Description
    ) returns AdoptionApplicationsSrv;


    action deleteApplication(
        ID : GUID
    ) returns String;


    // =========================================================
    // ADOPTION ACTIONS
    // createAdoption / deleteAdoption removed: adoption records are
    // generated by approveApplication and are read-only (FR-ADM-010)
    // =========================================================


    // =========================================================
    // HEALTH RECORD ACTIONS
    // =========================================================

    action createHealthRecord(
        animalID         : GUID,
        checkupDate      : Date,
        healthStatus     : HealthStatus,
        diagnosis        : Description,
        treatment        : Description,
        medication       : Description,
        veterinarianName : Name,
        weight           : Weight,
        nextCheckupDate  : Date,
        remarks          : Description,
        medicalDocument  : String(500)
    ) returns HealthRecordsSrv;


    action deleteHealthRecord(
        ID : GUID
    ) returns String;


    // =========================================================
    // INSPECTION ACTIONS
    // =========================================================

    action createInspection(
        adoptionID         : GUID,
        inspectorID        : GUID,
        inspectionDate     : Date,
        inspectionType     : InspectionType,
        existingPetDetails : Description,
        result             : InspectionResult,
        remarks            : Description,
        inspectionDocument : String(500)
    ) returns InspectionsSrv;


    action deleteInspection(
        ID : GUID
    ) returns String;

}