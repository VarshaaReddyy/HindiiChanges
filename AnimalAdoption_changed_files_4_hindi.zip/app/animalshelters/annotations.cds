using CatalogService as service from '../../srv/cat-service';
annotate service.SheltersSrv with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>shelterName}',
                Value : shelterName,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>shelterCode}',
                Value : shelterCode,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>addressLine1}',
                Value : addressLine1,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>addressLine2}',
                Value : addressLine2,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>city}',
                Value : city,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>state}',
                Value : state,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>postalCode}',
                Value : postalCode,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>country}',
                Value : country,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>contactNumber}',
                Value : contactNumber,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>email}',
                Value : email,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>website}',
                Value : website,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>capacity}',
                Value : capacity,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>currentOccupancy}',
                Value : currentOccupancy,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>openingTime}',
                Value : operatingTime,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>closingTime}',
                Value : closingTime,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>shelterType}',
                Value : shelterType,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>licenseNumber}',
                Value : licenseNumber,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
);

