using CatalogService as service from '../../srv/cat-service';
annotate service.UsersSrv with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>firstName}',
                Value : firstName,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastName}',
                Value : lastName,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>email}',
                Value : email,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>phone}',
                Value : phoneNumber,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>address}',
                Value : address,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>city}',
                Value : city,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>state}',
                Value : state,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>postalCode}',
                Value : postalCode,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>role}',
                Value : role,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>status}',
                Value : status,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
);

