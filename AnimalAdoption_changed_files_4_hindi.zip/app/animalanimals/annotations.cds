using CatalogService as service from '../../srv/cat-service';
annotate service.AnimalsSrv with @(
    UI.HeaderInfo : {
        TypeName : '{i18n>animal}',
        TypeNamePlural : '{i18n>animals}'
    },

    UI.SelectionFields : [
        name,
        species,
        animalStatus
    ],

    UI.LineItem : [
    {
        $Type : 'UI.DataField',
        Value : name,
        Label : '{i18n>name}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : species,
        Label : '{i18n>species}',
            ![@HTML5.CssDefaults] : { width : '7rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : breed,
        Label : '{i18n>breed}',
            ![@HTML5.CssDefaults] : { width : '10rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : age,
        Label : '{i18n>age}',
            ![@HTML5.CssDefaults] : { width : '6rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : animalStatus,
        Label : '{i18n>status}',
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : shelter_ID,
        Label : '{i18n>shelter}',
            ![@HTML5.CssDefaults] : { width : '10rem' }
        },
    {
        $Type : 'UI.DataField',
        Value : adoptionEligibility,
        Label : '{i18n>adoptionEligibility}',
        Criticality : eligibilityCriticality,
            ![@HTML5.CssDefaults] : { width : '15rem' }
        }
    ],
    
);
annotate service.AnimalsSrv with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>name}',
                Value : name,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>species}',
                Value : species,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>breed}',
                Value : breed,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>gender}',
                Value : gender,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>ageYears}',
                Value : age,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>arrivalDate}',
                Value : arrivalDate,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>adoptionStatus}',
                Value : animalStatus,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>vaccinationStatus}',
                Value : vaccinationStatus,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>spayedNeutered}',
                Value : spayedOrNeutered,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>photo}',
                Value : photo,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>description}',
                Value : description,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'HealthSummaryFacet',
            Label : '{i18n>healthEligibility}',
            Target : '@UI.FieldGroup#HealthSummary',
        },
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'HealthRecordsFacet',
            Label : '{i18n>healthRecords}',
            Target : 'healthRecords/@UI.LineItem',
        }
    ],
    


    
);

annotate service.AnimalsSrv with {
    shelter @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'SheltersSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : shelter_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'shelterName',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'shelterCode',
            },
        ],
    }
};

// FR-ADM-016: adoption eligibility derived from status, health and vaccination
annotate service.AnimalsSrv with @(
    UI.FieldGroup #HealthSummary : {
        $Type : 'UI.FieldGroupType',
        Data : [
            { $Type : 'UI.DataField', Value : adoptionEligibility, Label : '{i18n>adoptionEligibility}', Criticality : eligibilityCriticality },
            { $Type : 'UI.DataField', Value : animalStatus,        Label : '{i18n>adoptionStatus}' },
            { $Type : 'UI.DataField', Value : vaccinationStatus,   Label : '{i18n>vaccinationStatus}' },
            { $Type : 'UI.DataField', Value : spayedOrNeutered,    Label : '{i18n>spayedNeutered}' }
        ]
    }
);
