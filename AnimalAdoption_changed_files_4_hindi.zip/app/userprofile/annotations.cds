using UserCatalogService as service from '../../srv/user-service';
annotate service.UsersSrv with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>firstName}',
                Value : firstName,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastName}',
                Value : lastName,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>email}',
                Value : email,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>phone}',
                Value : phoneNumber,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>address}',
                Value : address,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>city}',
                Value : city,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>state}',
                Value : state,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>postalCode}',
                Value : postalCode,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>role}',
                Value : role,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>status}',
                Value : status,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
    UI.LineItem : [
        {
            $Type : 'UI.DataField',
            Label : '{i18n>firstName}',
            Value : firstName,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>lastName}',
            Value : lastName,
            ![@HTML5.CssDefaults] : { width : '8rem' }
        },
        {
            $Type : 'UI.DataField',
            Label : '{i18n>email}',
            Value : email,
            ![@HTML5.CssDefaults] : { width : '14rem' }
        }
    ],
);



// Edit Profile dialog opens pre-filled with the current values;
// email is the login identity and is not editable here
annotate service.UsersSrv actions {
    editProfile(
        firstName   @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/firstName' } }   @title : '{i18n>firstName}',
        lastName    @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/lastName' } }    @title : '{i18n>lastName}',
        email       @UI.Hidden,
        phoneNumber @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/phoneNumber' } } @title : '{i18n>phone}',
        address     @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/address' } }     @title : '{i18n>address}',
        city        @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/city' } }        @title : '{i18n>city}',
        state       @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/state' } }       @title : '{i18n>state}',
        postalCode  @UI.ParameterDefaultValue : { $edmJson : { $Path : 'in/postalCode' } }  @title : '{i18n>postalCode}'
    );
};


// Profile page title = the user's name (Edit / Save buttons come from draft)
annotate service.UsersSrv with @(
    UI.HeaderInfo : {
        TypeName       : '{i18n>profile}',
        TypeNamePlural : '{i18n>myProfile}',
        Title          : { Value : firstName },
        Description    : { Value : email }
    }
);
