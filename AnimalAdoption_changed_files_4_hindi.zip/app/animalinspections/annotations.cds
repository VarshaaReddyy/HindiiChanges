using CatalogService as service from '../../srv/cat-service';
annotate service.InspectionsSrv with @(
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>lastChangedAt}',
                Value : modifiedAt,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>inspectionDate}',
                Value : inspectionDate,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>inspectionType}',
                Value : inspectionType,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>existingPetDetails}',
                Value : existingPetDetails,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>result}',
                Value : result,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>remarks}',
                Value : remarks,
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>inspectionDocument}',
                Value : inspectionDocument,
            },
        ],
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : '{i18n>generalInformation}',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
);

annotate service.InspectionsSrv with {
    adoption @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'AdoptionsSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : adoption_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'adoptionDate',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'status',
            },
        ],
    }
};

annotate service.InspectionsSrv with {
    inspector @Common.ValueList : {
        $Type : 'Common.ValueListType',
        CollectionPath : 'UsersSrv',
        Parameters : [
            {
                $Type : 'Common.ValueListParameterInOut',
                LocalDataProperty : inspector_ID,
                ValueListProperty : 'ID',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'firstName',
            },
            {
                $Type : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty : 'lastName',
            },
        ],
    }
};

